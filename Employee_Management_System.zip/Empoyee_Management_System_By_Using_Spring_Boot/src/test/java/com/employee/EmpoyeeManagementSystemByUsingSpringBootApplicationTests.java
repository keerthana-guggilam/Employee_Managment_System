package com.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpoyeeManagementSystemByUsingSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
