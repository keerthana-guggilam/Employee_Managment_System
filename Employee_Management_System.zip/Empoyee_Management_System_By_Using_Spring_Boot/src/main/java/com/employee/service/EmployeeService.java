package com.employee.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.employee.controller.EmployeeController;
import com.employee.dao.EmployeeDAO;
import com.employee.dto.EmployeeDetailsDto;
import com.employee.entity.EmployeeDetails;

@Service
/*@Service: It is used to specify the class is used to write the business logic code 
 * to perform validation ,calculations and also used to create the structure of the response
 * -> and also used to create the bean for the service classes */
public class EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;
	@Autowired
	private ModelMapper mapper;
	
   
	
	public void employeeRegistration(EmployeeDetailsDto employeeDetailsDto) {
		
		EmployeeDetails employeeDetails=mapper.map(employeeDetailsDto, EmployeeDetails.class);
//		EmployeeDetails employeeDetails=new EmployeeDetails();
//		employeeDetails.setEmpName(employeeDetailsDto.getEmpName());
//		employeeDetails.setEmpEmailId(employeeDetailsDto.getEmpEmailId());
//		employeeDetails.setMobileNumber(employeeDetailsDto.getMobileNumber());
//		employeeDetails.setAddress(employeeDetailsDto.getAddress());
//		employeeDetails.setDeptno(employeeDetailsDto.getDeptno());
//		employeeDetails.setSalary(employeeDetailsDto.getSalary());
//		employeeDetails.setGender(employeeDetailsDto.getGender());
		employeeDAO.insertEmployeeDetails(employeeDetails);

	}
	public List<EmployeeDetails> allEmployeeDetails() {
		return employeeDAO.getAllEmployeeDetails();
	}
	public void deleteEmployeeByUsingId(int empid) {
		employeeDAO.deleteEmployeeDetailsByUsingEmployeeId(empid);
	}
	public EmployeeDetails getEmployeeByUsingId(int empid) {
		return employeeDAO.getEmployeeDetailsByUsingPrimaryKey(empid);
	}
	
	public List<EmployeeDetails> filterEmployeeDetails(String filter){
		return employeeDAO.selectEmployeeDetailsByUsingEmpNameOrEmpEmailIdOrGenderOrAddress(filter);
	}

}
