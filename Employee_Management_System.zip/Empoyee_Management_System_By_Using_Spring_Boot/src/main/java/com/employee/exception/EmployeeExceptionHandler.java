package com.employee.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.ui.Model;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class EmployeeExceptionHandler {
	//@ResponseBody
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public String methodArgumentaNotValidExceptionHandler(MethodArgumentNotValidException  invalidData,Model model) {		
		Map<String, String> invalidMsg=new HashMap<String, String>();
		invalidData.getBindingResult().getFieldErrors().forEach(error->{
			invalidMsg.put(error.getField(),error.getDefaultMessage());
			
		});
	
		model.addAttribute("invalidMsg", invalidMsg);
		return "forward:/registrationPage";
	}

	}
