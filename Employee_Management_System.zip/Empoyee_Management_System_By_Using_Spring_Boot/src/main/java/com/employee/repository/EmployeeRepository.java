package com.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.entity.EmployeeDetails;

public interface EmployeeRepository extends JpaRepository<EmployeeDetails, Integer> 
{
	
	
	List<EmployeeDetails> findByEmpNameOrEmpEmailIdOrGenderOrAddress(String name,String emailid,String gender,String address);

}
