package com.employee.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "Employee_Details")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EmployeeDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int empid;
	@Column(nullable = false,name="Employee_Name")
	private String empName;
	@Column(nullable = false,unique = true,name="Emp_EmailId")
	private String empEmailId;
	@Column(nullable = false,unique = true,name="Mobile_Number")
	private long mobileNumber;
	@Column(nullable = false,name="Gender")
	private String gender;
	@Column(nullable = false,name="address")
	private String address;
	@Column(nullable = false,name="salary")
	private double salary;
	@Column(nullable = false,name="DeptNo")
	private int deptno;
}
