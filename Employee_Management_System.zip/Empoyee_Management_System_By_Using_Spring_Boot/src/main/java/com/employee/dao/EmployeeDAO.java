package com.employee.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.employee.entity.EmployeeDetails;
import com.employee.repository.EmployeeRepository;
@Repository
/* @Repository: It is used to specify the class is used to perform the curd operations by adding on the repository
 * and also used to create the bean for the  DAO classes*/
public class EmployeeDAO {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public EmployeeDetails insertEmployeeDetails(EmployeeDetails employeeDetails) {
		//insertion
		
		return employeeRepository.save(employeeDetails);
	}
	
	public List<EmployeeDetails> getAllEmployeeDetails() {
		return employeeRepository.findAll();
	}
	public void deleteEmployeeDetailsByUsingEmployeeId(int empid) {
		employeeRepository.deleteById(empid);
	}
	
	public EmployeeDetails getEmployeeDetailsByUsingPrimaryKey(int empid) {
		try {
		EmployeeDetails employeeDetails=employeeRepository.findById(empid).get();
		return employeeDetails;
		}
		catch (Exception e) {
		return null;
		}
		
	}
	public List<EmployeeDetails> selectEmployeeDetailsByUsingEmpNameOrEmpEmailIdOrGenderOrAddress(String filter){
		//selection
		
		return employeeRepository.findByEmpNameOrEmpEmailIdOrGenderOrAddress(filter, filter, filter, filter);
	}

}
