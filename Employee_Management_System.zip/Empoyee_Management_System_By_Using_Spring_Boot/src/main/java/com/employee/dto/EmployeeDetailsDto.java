package com.employee.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDetailsDto {

	
	private String empName;
	@Email(message="Invalid Email")
	private String empEmailId;
	@Min(value=6000000000l,message="Invalid Mobile Number")
	@Max(value=9999999999l,message="Inavlid Mobile Number")
	private long mobileNumber;
	@Pattern(regexp="Male|Female|Other",message="Invalid gender")
	private String gender;
	@NotBlank(message="Invalid address")
	private String address;
	@Positive(message="Invalid salary")
	private double salary;
	@Positive(message="Invalid deptno")
	private int deptno;
	
}
