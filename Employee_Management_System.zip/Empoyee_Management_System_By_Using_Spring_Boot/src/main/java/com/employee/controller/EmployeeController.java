package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.employee.EmpoyeeManagementSystemByUsingSpringBootApplication;
import com.employee.dto.EmployeeDetailsDto;
import com.employee.entity.EmployeeDetails;
import com.employee.service.EmployeeService;

import jakarta.validation.Valid;

@Controller
public class EmployeeController {

    private final EmpoyeeManagementSystemByUsingSpringBootApplication empoyeeManagementSystemByUsingSpringBootApplication;

//    private final EmpoyeeManagementSystemByUsingSpringBootApplication empoyeeManagementSystemByUsingSpringBootApplication;
//
//    EmployeeController(EmpoyeeManagementSystemByUsingSpringBootApplication empoyeeManagementSystemByUsingSpringBootApplication) {
//        this.empoyeeManagementSystemByUsingSpringBootApplication = empoyeeManagementSystemByUsingSpringBootApplication;
//    }
	
	@Autowired
	private EmployeeService employeeService;

    EmployeeController(EmpoyeeManagementSystemByUsingSpringBootApplication empoyeeManagementSystemByUsingSpringBootApplication) {
        this.empoyeeManagementSystemByUsingSpringBootApplication = empoyeeManagementSystemByUsingSpringBootApplication;
    }
	@RequestMapping("/registrationPage")
	public String employeeRegistrationPage(Model model){
		model.addAttribute("employeeDetails", new EmployeeDetailsDto());
		return "EmployeeRegistration";
		}
	@RequestMapping("/registration")
	public String employeeRegistration(@Valid EmployeeDetailsDto employeeDetailsDto) {
		System.out.println(employeeDetailsDto);
		employeeService.employeeRegistration(employeeDetailsDto);
		return "redirect:/getAllEmployeeDetails";
	}
	@RequestMapping("/getAllEmployeeDetails")
	public String getAllEmployeeDtails(Model model) {
		List<EmployeeDetails> allEmployeeDetails=employeeService.allEmployeeDetails();
		model.addAttribute("getAllEmployeeDetails",allEmployeeDetails);
		return "DisplayAllEmployeeDetails";
		
		
	}
	@RequestMapping("/deletebyid")
	public String deleteEmployeeDetailsByUsingId(int empid) {
		System.out.println(empid);
		employeeService.deleteEmployeeByUsingId(empid);
		return "redirect:/getAllEmployeeDetails";
	}
	@RequestMapping("/getbyusingid")
	public void getEmployeeDetailsByUsingId(int empid) {
		System.out.println(empid);
		EmployeeDetails employeeDetails=employeeService.getEmployeeByUsingId(empid);
		System.out.println(employeeDetails);
		
	}
	@RequestMapping("/filterby")
	public String filterEmployeeByUsingNameOrEmailIdOrAddressOrGender(String filter,Model model) {
		//System.out.println(filter);
		List<EmployeeDetails> filterEmployeeDetails=employeeService.filterEmployeeDetails(filter);
		model.addAttribute("getAllEmployeeDetails", filterEmployeeDetails);
		return "DisplayAllEmployeeDetails";
		
	}
	

}
