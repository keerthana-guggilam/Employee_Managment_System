package com.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/* @SpringBootApplication:
 * It is the combination of  @EnableAutoConfiguration,@ComponentScan,@SpringBootConfiguration
 * It is used to run spring boot Application
 * it is used to enable Auto configuration
 * it is used to scan component classes
 * it is used to enable the spring boot configuration*/

//@EnableAutoConfiguration
//@ComponentScan(basePackages = "com.employee")
//@SpringBootConfiguration


@SpringBootApplication

public class EmpoyeeManagementSystemByUsingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpoyeeManagementSystemByUsingSpringBootApplication.class, args);
	}

}
